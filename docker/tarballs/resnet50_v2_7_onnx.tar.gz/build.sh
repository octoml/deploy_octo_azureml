#!/bin/sh

if [ $# -lt 1 ]; then
  echo usage: build.sh name:tag, e.g. ecr.io/octoml/model:v1
  exit 1
fi
docker build --build-arg BASE_IMAGE=nvcr.io/nvidia/tritonserver:22.10-py3 --tag $1 --platform linux/x86_64 --file docker_build_context/Dockerfile docker_build_context